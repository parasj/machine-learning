package com.proj3;

public class Main {
	public static void main(String[] args){
		ExperimentRunner r = new ExperimentRunner();
		r.run();
		System.exit(0);
	}
}