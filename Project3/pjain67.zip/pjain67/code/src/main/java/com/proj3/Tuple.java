package com.proj3;

/**
 * code
 */
public class Tuple<T, T1> {
    public T _1;
    public T1 _2;

    public Tuple(T _1, T1 _2) {
        this._1 = _1;
        this._2 = _2;
    }
}
