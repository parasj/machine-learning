package com.proj3;

/**
 * code
 */
public class FileLocator {
    public static final String BASE_DIR = "/Users/parasjain/Dropbox/Class/4641_ml/Project3/";
    public static final String DATA_DIR = BASE_DIR + "data/";
}
