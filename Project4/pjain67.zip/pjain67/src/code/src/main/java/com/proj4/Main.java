package com.proj4;

/**
 * code
 */
public class Main {
    public static void main(String[] args) {
//        PlotTest exp = new PlotTest(11, 11, 0.8);
//        exp.runValueIteration(false);
//        exp.runPolicyIteration(false);
//        exp.runQLearning(100);
    }
}
