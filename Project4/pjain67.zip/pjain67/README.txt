RL Sim was used for these experiments. The package can be downloaded from http://www.cs.cmu.edu/~awm/rlsim/.

1. Value iteration - the GUI was used for this
2. Policy iteration - the GUI was used for this
3. Q-learning - run 'make scala' in the main directory
4. P-sweeping - run 'make scala' in the main directory