package com.jainlabs;

/**
 * Project2
 */
public enum UseOptAlg {
    RandomizedHillClimbing, SimulatedAnnealing, GeneticAlgorithms, MIMIC;
}
